sap.ui.define(["sap/fe/core/PageController"],function(e){"use strict";return e.extend("monitorfacturas.detalleorden.ext.view.Detalles",{})});
//# sourceMappingURL=Detalles.controller.js.map