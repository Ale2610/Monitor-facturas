sap.ui.define(
    [
        'sap/fe/core/PageController'
    ],
    function(PageController) {
        'use strict';

        return PageController.extend('monitorfacturas.detalleorden.ext.view.Detalles', {
            
        });
    }
);
