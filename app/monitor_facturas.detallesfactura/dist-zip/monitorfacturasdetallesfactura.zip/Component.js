sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("monitorfacturas.detallesfactura.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map