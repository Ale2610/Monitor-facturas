sap.ui.define(["sap/fe/core/PageController"],function(e){"use strict";return e.extend("monitorfacturas.facturaorden.ext.view.DetalleCompra",{})});
//# sourceMappingURL=DetalleCompra.controller.js.map